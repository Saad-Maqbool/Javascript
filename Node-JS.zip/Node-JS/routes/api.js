    var express = require('express');
    var router = express.Router();
    var mongoose = require('mongoose');
    var Post = mongoose.model('Post');

    function isAuthenticated (req, res, next) {

    if(req.method === "GET"){
    return next();
    }
    if (req.isAuthenticated()){
    return next();
    }


    return res.redirect('/#login');
    };


    router.use('/posts', isAuthenticated);

    router.route('/posts')

    .post(function(req, res){

    var post = new Post();
    post.text = req.body.text;
    post.created_by = req.body.created_by;
    post.save().then(function (post) {
    return res.json(post);
    }).catch((err) =>{
    return res.send(500,err);
    })
    })

    .get(function(req, res){
    console.log('debug1');
    Post.find().then(function (posts) {
    return res.send(200,posts);
    }).catch((err)=>{return res.send(500,err);})
    });


    router.route('/posts/:id')

    .get(function(req, res){
    Post.findById(req.params.id).then(function (post) {
    res.json(post);
    }).catch((err) =>{
    return res.send(err);

    });
    })

    .put(function(req, res){
    Post.findById(req.params.id).then(function (post) {
    post.created_by = req.body.created_by;
    post.text = req.body.text;
    post.save().then(function (post) {
    res.json(post);
    })
    }).catch((err) =>{
    return res.send(err);
    })
    })

    .delete(function(req, res) {
    Post.remove({_id: req.params.id}).then(function () {
    res.json("deleted :(");
    }).catch((err)=>{
    return res.send(err);
    })

    });

    module.exports = router;